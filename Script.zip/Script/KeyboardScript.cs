﻿using UnityEngine;
using System.Collections;

public class KeyboardScript : MonoBehaviour {

    public int playerTurnAxisKeyBoard= 0;
    public int playerRunAxsisKeyBoard = 0;

    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

        playerTurnAxisKeyBoard = 100;
	
	}
}
